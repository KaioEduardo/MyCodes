package com.example.app03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    // atributos da View
    private Button btnWeb, btnPhone, btnNovaTela;
    private EditText edtNome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//Obter a referência dos controles da View
        edtNome = (EditText) findViewById(R.id.edtNome);
        btnWeb = (Button) findViewById(R.id.btnWeb);
        btnPhone = (Button) findViewById(R.id.btnPhone);
        btnNovaTela = (Button) findViewById(R.id.btnNovaTela);
// Associar o tratador de eventos
        btnWeb.setOnClickListener(this);
        btnPhone.setOnClickListener(this);
        btnNovaTela.setOnClickListener(this);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnWeb: // botão Web
            { // Guardar o endereço URI
                Uri uri = Uri.parse("http://www.google.com");
// Criar a intenção implícita
                Intent it = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(it); //Iniciar a intenção
                break;
            }
            case R.id.btnPhone:

                // botão Chamada
            { // Guardar o endereço URI

                Uri uri = Uri.parse("tel:123456789");
                Intent it = new Intent(Intent.ACTION_DIAL, uri);
                startActivity(it);
                break;
            }
/*
            case R.id.btnNovaTela: // botão nova tela
            { // Criar a intenção explícita
                Intent it = new Intent(this, Tela2activity.class);
                startActivity(it);
                break;
            }*/
        }
    }
}

