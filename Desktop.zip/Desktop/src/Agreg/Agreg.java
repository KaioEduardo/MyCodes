/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Agreg;


public class Agreg {

    public String marcaPlacaMae, modeloPlacaMae;
    public double precoPlacaMae;
    public String tipoProcessador, marcaHD, modeloHD;
    public double precoHD;
    public String tipoHD;
    public int capacidadeHD;
    public String marcaPlacaVideo, modeloPlacaVideo;
    public double precoPlacaVideo; 
    public String padrao, marcaMemoria, modeloMemoria;
    public double precoMemoria;
    public String tipoMemoria;
    public int capacidadeMemoria;
    
public class PlacaMae {

public String marca, modelo, tipoProcessador;

public double preco;

}



public class HD {

public String marca, modelo, tipo;

public double preco;

public int capacidade;

}



public class PlacaVideo {

public String marca, modelo;

public double preco;

public int capacidade;

}



public class Memoria {

public String marca, modelo, tipo;

public double preco;

public int capacidade;

}

  
public class Desktop {

public String tipoCooler;


public PlacaMae pm = new PlacaMae();

public PlacaVideo pv = new PlacaVideo();

public HD hd = new HD();

public Memoria me = new Memoria();




    
    
public static void main(String[] args) {
        
    }
    
}
